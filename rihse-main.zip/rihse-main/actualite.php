<?php $actualite =  "class='active'" ?>
<?php  include 'header.php';?>




    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area gradient-bg bg-cover shadow dark text-light text-center" style="background-image: url(assets/img/actualiteRihse.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>ACTUALITE</h1>
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Pages</a></li>
                      
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->




<?php include 'shownews.php'; ?>




  
<?php include 'footer.php'; ?>
