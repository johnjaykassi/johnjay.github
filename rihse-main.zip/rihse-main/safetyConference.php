<?php  include 'header.php';?>


<!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area gradient-bg bg-cover shadow dark text-light text-center" style="background-image: url(assets/img/Blog.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                	<p style="font-size:34px">Qui sommes nous ?</p>
                    <h1 style="font-size:60px">RIHSE</h1>
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li><a href="#">Pages</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
<!-- End Breadcrumb -->


 <!-- Start CONGRES J2
    ============================================= -->
    <div class="blog-area single full-blog full-blog default-padding">
        <div class="container">
            <div class="blog-items">
                <div class="row">
                    <div class="blog-content col-lg-12  col-md-12">
                        <div class="single-item">

                            <div class="blog-item-box">
                                <div class="item">
                                    <!-- Start Post Thumb -->
                                    <div class="thumb">
                                        <center><img src="assets/img/news.jpg" alt="Thumb"></center>
                                        <div class="cats">
                                            <a href="#">SAFETY CONFERENCE</a>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- End CONGRES J2 -->


















<?php include 'shownews.php'; ?>


<?php include 'footer.php'; ?>